#ifndef Disco_H_INCLUDED
#define Disco_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>
#include<stddef.h>
#include<string.h>
#include<time.h>
#include<unistd.h>


typedef struct {
  int32_t magico;    // número que identifica que isto é um disco (0xe1d15c0)
  int32_t n_bloco;   // número total de blocos no disco
  int32_t tam_bloco; // número de bytes em cada bloco (mín 64)
  int32_t n_cil;     // número de cilindros no disco
  int32_t n_sup;     // número de superfícies no disco
  int32_t n_set;     // número de setores por trilha
  int32_t rpm;       // velocidade de rotação do disco
  int32_t t_busca;   // tempo fixo para qualquer movimento do braco (micro s)
  int32_t t_cil;     // tempo adicional de movimentacao para cada cilindro
  int32_t cil_atual; // em que cilindro está o braco
} disco_t;

#define MAGICO 0xe1d15c0

// aloca e inicializa uma estrutura que descreve um disco
disco_t *disco_init(int32_t tam_bloco, int32_t n_cil, int32_t n_sup,
                    int32_t n_set, int32_t rpm, int32_t t_busca, int32_t t_cil);


// inicializa um disco a partir de uma imagem em arquivo
disco_t *disco_init_arquivo(char *nome_arq);

// grava a imagem de um disco em arquivo
void disco_grava_arquivo(disco_t *disco, char *nome_arq);

// acaba com o disco
void disco_fim(disco_t *disco);

// le um bloco do disco, coloca em buf
void disco_le(disco_t *disco, int bloco, void *buf);

// grava um bloco no disco, a partir do conteúdo em buf
void disco_grava(disco_t *disco, int bloco, void *buf);

#endif
