#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include<stdbool.h>

#include<pthread.h>
#include "fila.h"


Fila* fila_cria (void)
{
   Fila* f = (Fila*) malloc(sizeof(Fila));
   f->ini = NULL;
   f->fim = NULL;
   return f;
}

int fila_vazia (Fila* f)
{
    return (f->ini==NULL);
}


bool fila_insere (Fila* f, void* v)
{
  No* n = (No*) malloc(sizeof (No));
  n->dados = v;               /* armazena dadosrma��o	         */
  n->prox = NULL;      /* novo n� passa a ser o �ltimo      */
  if (f->fim != NULL){   /* verifica se lista n�o estava vazia */
    f->fim->prox = n;
    n->ant = f->fim;
  }else{
    n->ant = NULL; /* fila estava vazia                            */
    f->ini = n;
  }
  f->fim = n;
  return true;
}

void* fila_retira_no(Fila *f, No *no){
  void* v = no->dados;
  if(f->ini==no){
    f->ini = no->prox;
    //no->prox->ant = NULL;
  }else if(f->fim==no){
    f->fim = no->ant;
    no->ant->prox = NULL;
  }else{
    no->prox->ant = no->ant;
    no->ant->prox = no->prox;
  }

  if (f->ini == NULL)	/* verifica se fila ficou vazia */
     f->fim = NULL;

  free(no);
  return v;
}



void* fila_retira (Fila* f){
   if (fila_vazia(f)) {
      printf("Fila vazia.\n");
      return NULL;
                  /* aborta programa */
    }

   No* t = f->ini;
   void* v = t->dados;
   f->ini = t->prox;
   if (f->ini == NULL)	/* verifica se fila ficou vazia */
      f->fim = NULL;
   free(t);
   return v;
}

void* fila_top(Fila* f){
  if (fila_vazia(f)) {
     printf("Fila vazia.\n");
     return NULL;                   /* aborta programa */
   }

   void* v = f->ini->dados;

   return v;

}


void fila_libera (Fila* f)
{
   No* q = f->ini;
   while (q!=NULL) {
      No* t = q->prox;
      free(q->dados);
      free(q);
      q = t;
   }
   free(f);
}

int fila_tamanho(Fila* f)
{
   No * no = f->ini;
   int cont = 0;
   while (no!=NULL) {
      no = no->prox;
      cont++;
   }
   return cont;
}
