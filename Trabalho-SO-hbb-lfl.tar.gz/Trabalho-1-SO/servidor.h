#ifndef Servidor_H_INCLUDED
#define Servidor_H_INCLUDED

#include"buffer.h"
#include"disco.h"

typedef unsigned int uint;

void servidor_cliente_test();

void servidor_proxy_cliente_test();

#endif
