#include "buffer.h"
#include "testes.h"
#include "servidor.h"
#include "disco.h"

int main(){
    srand(time(0));
    //no_thread_test();
    //one_thread_test();
    //multithread_test();
    servidor_cliente_test();

    //servidor_proxy_cliente_test();


    return 0;
}
