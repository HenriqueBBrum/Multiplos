#ifndef Buffer_H_INCLUDED
#define Buffer_H_INCLUDED

#include<stdbool.h>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<pthread.h>
#include"fila.h"
#include <unistd.h>
#include <sys/time.h>

typedef unsigned int uint;

typedef struct{
    int inicio, fim;
    uint tam;
    uint qnt_elementos;
    uint qnt_inserida;
    uint qnt_removida;
    void* dados;

    pthread_mutex_t mutex;
    pthread_cond_t inserir;
    pthread_cond_t remover;

    Fila* insercoes;
    pthread_mutex_t mutex_f_insercoes;

    Fila* remocoes;
    pthread_mutex_t mutex_f_remocoes;

}Buffer;

Buffer *buffer_inicializa(uint cap);

void buffer_finaliza(Buffer *buf);

bool buffer_insere(Buffer* buf, void* p, uint tam);

bool buffer_insere_bloqueante(Buffer *buf, void *p, uint tam);

bool buffer_insere_bloqueante_simples(Buffer *buf, void *p, uint tam);

bool buffer_insere_nao_bloqueante(Buffer *buf, void *p, uint tam);

bool buffer_insere_nao_bloqueante_simples(Buffer *buf, void *p, uint tam);

bool buffer_remove(Buffer* buf, void*p, uint cap, uint* tam);

bool buffer_remove_nao_bloqueante(Buffer* buf, void*p, uint cap, uint* tam);

bool buffer_remove_nao_bloqueante_simples(Buffer* buf, void*p, uint cap, uint* tam);

bool buffer_remove_bloqueante(Buffer* buf, void*p, uint cap, uint* tam);

bool buffer_remove_bloqueante_simples(Buffer* buf, void*p, uint cap, uint* tam);

uint buffer_ndados(Buffer *buf);

uint buffer_livre(Buffer *buf);

#endif // Buffer_H_INCLUDED
