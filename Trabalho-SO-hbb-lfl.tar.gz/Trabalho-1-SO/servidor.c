#include"servidor.h"

#include<sched.h>
#include<string.h>
#include<limits.h>

#define COMB_SEQ_ALE 7
#define NUM_CLIENTES 6
#define NUM_THREAD_SERVIDOR_P 3
#define NUM_PEDIDOS_CLIENTE 1000


typedef enum{
  P_ESCRITA,
  P_LEITURA,
  R_ESCRITA,
  R_LEITURA
}Tipo_msg;

typedef struct{
  Tipo_msg tipo_msg;
  Buffer* buf;
  int num_serie;
  int bloco;
  void* dados;
}Mensagem;

typedef struct{
  Buffer* buf;
  int id;
  bool sequencial;
  pthread_t thread_pedidos;
  pthread_t thread_buffer;
}Cliente;

typedef struct{
  disco_t* disco;
  Buffer* buf;
  pthread_t thread;
}Servidor;

typedef struct{
  Fila* fila;
  pthread_mutex_t f_mutex;
  pthread_cond_t f_cond;

  Buffer* buf;
  bool usa_elevador;
  uint entrel;

  pthread_t thread_buf[NUM_THREAD_SERVIDOR_P];
  pthread_t thread_fila;
}Servidor_proxy;

char nome_arq_disco[100] = "imagem_disco.bin";

//--------------------------------------- Variaveis globais de controle --------------------------------------


uint clientes_ativos = 0;
uint servidor_ativo = 0;
uint servidor_p_buf_ativo = 0;
uint servidor_p_fila_ativo = 0;



//--------------------------------------- Funções de Mensagem --------------------------------------

static Mensagem* cria_msg(Tipo_msg tipo_msg, Buffer* buf, int num_serie, int bloco, void* dados){
  Mensagem* msg = malloc(sizeof(*msg));
  if(msg==NULL) return NULL;

  msg->tipo_msg = tipo_msg;
  msg->buf = buf;
  msg->num_serie = num_serie;
  msg->bloco = bloco;
  msg->dados = dados;

  return msg;
}

static bool envia_pedido_leitura(Buffer* buf_origem, Buffer* buf_destino, int num_serie, int bloco){
  if(buf_origem==NULL || buf_destino==NULL)
    return false;
  Mensagem* msg = cria_msg(P_LEITURA,buf_origem,num_serie,bloco,NULL);
  bool ans = buffer_insere_bloqueante(buf_destino,msg,sizeof(*msg));
  free(msg);
  return ans;
}

static bool envia_pedido_escrita(Buffer* buf_origem, Buffer* buf_destino, void* dados, int num_serie, int bloco){
  if(buf_origem==NULL || buf_destino==NULL)
    return false;
  Mensagem* msg = cria_msg(P_ESCRITA,buf_origem,num_serie,bloco,dados);
  bool ans = buffer_insere_bloqueante(buf_destino,msg,sizeof(*msg));
  free(msg);

  return ans;
}

static bool envia_resposta_leitura(Buffer* buf_origem, Buffer* buf_destino, void* dados, int num_serie){
  if(buf_origem==NULL || buf_destino==NULL)
    return false;
  Mensagem* msg = cria_msg(R_LEITURA,buf_origem,num_serie,-1,dados);
  bool ans = buffer_insere_bloqueante(buf_destino,msg,sizeof(*msg));
  free(msg);

  return ans;
}

static bool envia_resposta_escrita(Buffer* buf_origem, Buffer* buf_destino, int num_serie){
  if(buf_origem==NULL || buf_destino==NULL)
    return false;
  Mensagem* msg = cria_msg(P_ESCRITA,buf_origem,num_serie,-1,NULL);
  bool ans = buffer_insere_bloqueante(buf_destino,msg,sizeof(*msg));
  free(msg);

  return ans;
}

static bool envia_msg(Mensagem* msg, Buffer* destino){
  bool ans = buffer_insere_bloqueante(destino, msg, sizeof(*msg));
  return ans;
}

//--------------------------------------- Funções do Servidor de Disco --------------------------------------

static Servidor* cria_servidor(disco_t* disco, Buffer* buf){
  Servidor* servidor =  malloc(sizeof(*servidor));
  if(servidor==NULL) return NULL;

  servidor->disco = disco;
  servidor->buf = buf;

  return servidor;
}

static void avalia_pedidos_disco_(Servidor* servidor){
  uint tam;
  Mensagem* pedido = cria_msg(-1,NULL,-1,0,NULL);
  if(buffer_remove_bloqueante(servidor->buf,pedido,sizeof(*pedido),&tam)){
    if(pedido->tipo_msg == P_ESCRITA){
      disco_grava(servidor->disco,pedido->bloco,pedido->dados);
      free(pedido->dados);
      envia_resposta_escrita(servidor->buf,pedido->buf,pedido->num_serie);
    }else if(pedido->tipo_msg == P_LEITURA){
      char* dados = malloc((servidor->disco->tam_bloco+100)*sizeof(*dados));
      for(uint i = 0 ; i<servidor->disco->tam_bloco;i++) dados[i] = '\0';
      disco_le(servidor->disco,pedido->bloco,dados);
      if(!envia_resposta_leitura(servidor->buf,pedido->buf,dados,pedido->num_serie))
        free(dados);
    }
  }
  free(pedido);
  usleep(1);
}

static void* avalia_pedidos_disco_sem_proxy(void* args){
  ++servidor_ativo;
  Servidor* servidor  = (Servidor*)args;
  while(clientes_ativos==0)sched_yield();
  while(clientes_ativos!=0 || buffer_ndados(servidor->buf)>0){
      avalia_pedidos_disco_(servidor);
  }
  --servidor_ativo;
  return NULL;
}

static void* avalia_pedidos_disco_com_proxy_e_elevador(void* args){
  ++servidor_ativo;
  Servidor* servidor  = (Servidor*)args;
  while(servidor_p_fila_ativo==0)sched_yield();
  while(servidor_p_fila_ativo!=0 || buffer_ndados(servidor->buf)>0){
      avalia_pedidos_disco_(servidor);
  }
  --servidor_ativo;
  return NULL;
}

static void* avalia_pedidos_disco_com_proxy(void* args){
  ++servidor_ativo;
  Servidor* servidor  = (Servidor*)args;
  while(servidor_p_buf_ativo==0)sched_yield();
  while(servidor_p_buf_ativo!=0 || buffer_ndados(servidor->buf)>0){
      avalia_pedidos_disco_(servidor);
  }
  --servidor_ativo;
  return NULL;
}

static bool run_servidor_disco(Servidor* servidor, bool com_proxy, bool com_elevador){
  int status = 0;
  if(com_proxy){
    if(com_elevador)
      status = pthread_create(&servidor->thread,NULL,avalia_pedidos_disco_com_proxy_e_elevador,servidor);
    else
      status = pthread_create(&servidor->thread,NULL,avalia_pedidos_disco_com_proxy,servidor);
  }
  else status = pthread_create(&servidor->thread,NULL,avalia_pedidos_disco_sem_proxy,servidor);
  return status;
}

static disco_t* cria_disco(){
  FILE* arq_disco = fopen(nome_arq_disco,"r");
  disco_t* disco = NULL;
  if(arq_disco==NULL){
    disco = disco_init(1000,50,5,40,7500,3,6);
    disco_grava_arquivo(disco,nome_arq_disco);
  }else{
    disco = disco_init_arquivo(nome_arq_disco);
  }
  fclose(arq_disco);
  return disco;

}

static void finaliza_servidor(Servidor* servidor){
  buffer_finaliza(servidor->buf);
  disco_fim(servidor->disco);
  free(servidor);
}


//--------------------------------------- Funções do Servidor Proxy --------------------------------------

typedef struct{
  Servidor* servidor;
  Servidor_proxy* servidor_p;
}Proxy_t_arg;

static Servidor_proxy* cria_servidor_proxy(Fila* fila, Buffer* buf, bool usa_elevador, uint entrel){
  Servidor_proxy* servidor_p =  malloc(sizeof(*servidor_p));
  if(servidor_p==NULL) return NULL;

  servidor_p->fila = fila;
  servidor_p->buf = buf;
  servidor_p->usa_elevador = usa_elevador;
  servidor_p->entrel = entrel;
  servidor_p->f_mutex = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
  servidor_p->f_cond = (pthread_cond_t)PTHREAD_COND_INITIALIZER;

  return servidor_p;
}

static Mensagem* escolhe_melhor_(Fila* f, bool esq, int* anterior){
  int melhor = INT_MAX;
  No* melhor_no = NULL;
  for(uint i = 0;i<2;i++){
    No* q = f->ini;
    while (q!=NULL) {
       Mensagem* msg =  (Mensagem*)q->dados;
       if(esq){
         if(msg->bloco<=*anterior && abs(*anterior-msg->bloco)<abs(*anterior-melhor)){
            melhor = msg->bloco;
            melhor_no = q;
         }
       }else{
         if(msg->bloco>*anterior && abs(*anterior-msg->bloco)<abs(*anterior-melhor)){
            melhor = msg->bloco;
            melhor_no = q;
         }
       }
       q = q->prox;
    }
    if(melhor==INT_MAX) esq = !esq;
    else break;
  }
  *anterior = melhor;
  return (Mensagem*)fila_retira_no(f,melhor_no);
}

static Mensagem* escolhe_melhor(Servidor_proxy* servidor_p, bool esq, int* anterior){
  Fila* f = servidor_p->fila;
  if(f->ini==NULL) return NULL;
  pthread_mutex_lock(&servidor_p->f_mutex);
  while(fila_tamanho(f)==0) pthread_cond_wait(&servidor_p->f_cond,&servidor_p->f_mutex);
  No* melhor_no = f->ini;
  Mensagem* msg = (Mensagem*)f->ini->dados;
  if(*anterior == -1){
    *anterior = msg->bloco;
    msg = (Mensagem*)fila_retira_no(f,melhor_no);
    pthread_mutex_unlock(&servidor_p->f_mutex);
    return msg;
  }

  msg = escolhe_melhor_(f,esq,anterior);
  pthread_mutex_unlock(&servidor_p->f_mutex);
  return msg;
}

static void* manda_pedidos_proxy_disco(void* args){
  ++servidor_p_fila_ativo;
  Proxy_t_arg* param  = (Proxy_t_arg*)args;
  bool esq = true;
  int anterior = -1;
  while(servidor_p_buf_ativo==0) sched_yield();
  while(servidor_p_buf_ativo!=0 || fila_tamanho(param->servidor_p->fila)>0){
    Mensagem* msg  = escolhe_melhor(param->servidor_p,esq,&anterior);
    if(msg!=NULL){
      if(!envia_msg(msg,param->servidor->buf))
        free(msg->dados);
    }
    free(msg);
  }

  --servidor_p_fila_ativo;
  return NULL;
}

static uint entrelacamento(uint bloco, uint entrel, uint n_bloco){
  int aux = (bloco*entrel)%n_bloco;
  aux += (bloco*entrel)/n_bloco;
  return aux;
}

static void avalia_pedidos_proxy_(Servidor_proxy* servidor_p, Servidor* servidor){
  uint tam;
  Mensagem* pedido = cria_msg(-1,NULL,-1,0,NULL);
  if(buffer_remove_bloqueante(servidor_p->buf,pedido,sizeof(*pedido),&tam)){
    pedido->bloco = entrelacamento(pedido->bloco,servidor_p->entrel,servidor->disco->n_bloco);
    if(!servidor_p->usa_elevador){
      if(!envia_msg(pedido,servidor->buf))
        free(pedido->dados);
      free(pedido);
    }else{
      bool ans = false;
      pthread_mutex_lock(&servidor_p->f_mutex);
      ans = fila_insere(servidor_p->fila, pedido);
      pthread_cond_signal(&servidor_p->f_cond);
      pthread_mutex_unlock(&servidor_p->f_mutex);
      if(ans==false)
        free(pedido->dados);
    }
  }

  usleep(1);
}

static void* avalia_pedidos_proxy(void* args){
  ++servidor_p_buf_ativo;
  Proxy_t_arg* param  = (Proxy_t_arg*)args;
  while(clientes_ativos==0) sched_yield();
  while(clientes_ativos!=0 || buffer_ndados(param->servidor_p->buf)>0){
      avalia_pedidos_proxy_(param->servidor_p,param->servidor);
  }
  --servidor_p_buf_ativo;

  return NULL;
}

static int run_servidor_proxy(Servidor_proxy* servidor_p, Servidor* servidor){
  Proxy_t_arg* param  = malloc(sizeof(*param));
  param->servidor = servidor;
  param->servidor_p = servidor_p;
  int status = 0;
  for(uint  i =0;i<NUM_THREAD_SERVIDOR_P;i++){
    status = pthread_create(&servidor_p->thread_buf[i],NULL,avalia_pedidos_proxy,param);
  }
  if(servidor_p->usa_elevador)
    status = pthread_create(&servidor_p->thread_fila,NULL,manda_pedidos_proxy_disco,param);
  return status;
}

static void finaliza_servidor_proxy(Servidor_proxy* servidor_p){
  buffer_finaliza(servidor_p->buf);
  pthread_mutex_destroy(&servidor_p->f_mutex);
  pthread_cond_destroy(&servidor_p->f_cond);
  fila_libera(servidor_p->fila);
  free(servidor_p);
}


//--------------------------------------- Funções dos Clientes --------------------------------------

typedef struct{
  Servidor* servidor;
  Servidor_proxy* servidor_p;
  Cliente* cliente;
}Client_t_arg;

static Cliente* cria_cliente(Buffer* buf, int id, bool sequencial){
  Cliente* cliente =  malloc(sizeof(*cliente));
  if(cliente==NULL) return NULL;

  cliente->buf = buf;
  cliente->id = id;
  cliente->sequencial = sequencial;
  return cliente;
}

static void* avalia_respotas(void* args){
  Cliente* cliente =  (Cliente*)args;
  unsigned int tam;
  while(!servidor_ativo) sched_yield();
  while(servidor_ativo){
    Mensagem* resp = cria_msg(-1,NULL,-1,0,NULL);
    if(buffer_remove_bloqueante(cliente->buf,resp,sizeof(*resp),&tam)){
      if(resp->tipo_msg == R_ESCRITA){
      }else if(resp->tipo_msg == R_LEITURA){
        free(resp->dados);
      }
    }
    free(resp);
  }
  return NULL;
}

static void* manda_pedidos(void* args){
  ++clientes_ativos;
  Client_t_arg* param =  (Client_t_arg*)args;
  int bloco = 0, num_serie = 0;
  Buffer* destino = param->servidor->buf;
  if(param->servidor_p!=NULL)
    destino = param->servidor_p->buf;

  for(int  i =0 ;i<NUM_PEDIDOS_CLIENTE;i++){
    Tipo_msg tipo_msg = (Tipo_msg)rand()%2;
    if(param->cliente->sequencial){
       bloco++;
       if(bloco==param->servidor->disco->n_bloco)
          bloco = 0;
    }else{
       bloco = rand()%(param->servidor->disco->n_bloco);
     }

    if(tipo_msg == P_ESCRITA){
      uint  tam_bloco = param->servidor->disco->tam_bloco;
      char* dados = malloc(tam_bloco+10);
      for(uint i = 0 ; i<tam_bloco;i++) dados[i] = '-';
      if(!envia_pedido_escrita(param->cliente->buf,destino,dados,num_serie,bloco))
        free(dados);
    }else{
      envia_pedido_leitura(param->cliente->buf,destino,num_serie,bloco);
    }
    num_serie++;
    usleep(1);
  }
  free(param);
  --clientes_ativos;
  return NULL;
}

static int run_cliente(Cliente* cliente, Servidor* servidor, Servidor_proxy* servidor_p){
  Client_t_arg* param = malloc(sizeof(*param));
  param->cliente =cliente;
  param->servidor = (Servidor*)servidor;
  param->servidor_p = (Servidor_proxy*)servidor_p;
  int status1 = pthread_create(&cliente->thread_pedidos,NULL,manda_pedidos,param);
  int status2 = pthread_create(&cliente->thread_buffer,NULL,avalia_respotas,cliente);
  return status1+status2;

}

static void finaliza_cliente(Cliente* cliente){
  buffer_finaliza(cliente->buf);
  free(cliente);
}

//--------------------------------------- Funções de Teste--------------------------------------

static void servidor_cliente_join(FILE* fileptr, Cliente** clientes, Servidor* servidor, time_t start){
    void* val;
    time_t end;
    uint aux = 0;
    for(uint i = 0;i<NUM_CLIENTES;i++){
      pthread_join(clientes[i]->thread_pedidos,&val);
      pthread_join(clientes[i]->thread_buffer,&val);
      time(&end);
      aux = ((clientes[i]->buf->qnt_inserida+clientes[i]->buf->qnt_removida)/sizeof(Mensagem))/difftime(end, start);
      fprintf(fileptr,"Cliente i = %d Inseridas/Removidas = %ld msg, %d msg/seg\n",i,(clientes[i]->buf->qnt_inserida+clientes[i]->buf->qnt_removida)/sizeof(Mensagem) ,aux);
    }
    pthread_join(servidor->thread,&val);
    time(&end);
    aux = ((servidor->buf->qnt_inserida+servidor->buf->qnt_removida)/sizeof(Mensagem))/difftime(end, start);
    fprintf(fileptr,"Servidor Inseridas/Removidas = %ld msg, %d msg/seg\n",(servidor->buf->qnt_inserida+servidor->buf->qnt_removida)/sizeof(Mensagem), aux);
}

void servidor_cliente(FILE* fileptr,uint tam_buf, uint clientes_seq, uint clientes_ale){
  clientes_ativos = servidor_ativo = 0;
  servidor_p_buf_ativo =  servidor_p_fila_ativo = 0;
  time_t start;
  time(&start);
  Servidor* servidor = cria_servidor(cria_disco(),buffer_inicializa(tam_buf));
  fprintf(fileptr,"Disco n bloco = %d, tam blco = %d, rpm = %d\n", servidor->disco->n_bloco,servidor->disco->tam_bloco,servidor->disco->rpm);
  Cliente* clientes[NUM_CLIENTES];
  for(uint i = 0;i<clientes_ale;i++) clientes[i] = cria_cliente(buffer_inicializa(tam_buf),i,0);
  for(uint i = clientes_ale;i<NUM_CLIENTES;i++) clientes[i] = cria_cliente(buffer_inicializa(tam_buf),i,1);

  run_servidor_disco(servidor,0,0);
  for(uint i = 0;i<NUM_CLIENTES;i++) run_cliente(clientes[i],servidor,NULL);

  servidor_cliente_join(fileptr, clientes, servidor, start);

  for(uint i = 0;i<NUM_CLIENTES;i++) finaliza_cliente(clientes[i]);
  finaliza_servidor(servidor);
}

static void servidor_proxy_cliente_join(FILE* fileptr, Cliente** clientes, Servidor* servidor,Servidor_proxy* servidor_p, time_t start){
  void* val;
  time_t end;
  uint aux = 0;
  for(uint i = 0;i<NUM_CLIENTES;i++){
    pthread_join(clientes[i]->thread_pedidos,&val);
    pthread_join(clientes[i]->thread_buffer,&val);
    time(&end);
    aux = ((clientes[i]->buf->qnt_inserida+clientes[i]->buf->qnt_removida)/sizeof(Mensagem))/difftime(end, start);
    fprintf(fileptr,"Cliente i = %d Inseridas/Removidas = %ld msg, %d msg/seg\n",i,(clientes[i]->buf->qnt_inserida+clientes[i]->buf->qnt_removida)/sizeof(Mensagem) ,aux);
  }

  for(uint i = 0 ;i<NUM_THREAD_SERVIDOR_P;i++){
      pthread_join(servidor_p->thread_buf[i],&val);
  }
  if(servidor_p->usa_elevador)
    pthread_join(servidor_p->thread_fila,&val);
  time(&end);
  aux = ((servidor_p->buf->qnt_inserida+servidor_p->buf->qnt_removida)/sizeof(Mensagem))/difftime(end, start);
  fprintf(fileptr,"Servidor Intermediário Inseridas/Removidas no Buffer = %ld msg, %d msg/segg\n",(servidor_p->buf->qnt_inserida+servidor_p->buf->qnt_removida)/sizeof(Mensagem), aux);

  pthread_join(servidor->thread,&val);
  time(&end);
  aux = ((servidor->buf->qnt_inserida+servidor->buf->qnt_removida)/sizeof(Mensagem))/difftime(end, start);
  fprintf(fileptr,"Servidor Inseridas/Removidas = %ld msg, %d msg/seg\n",(servidor->buf->qnt_inserida+servidor->buf->qnt_removida)/sizeof(Mensagem), aux);

}

static void servidor_proxy_cliente(FILE* fileptr,uint tam_buf, uint clientes_seq, uint clientes_ale, bool usa_elevador, uint entrel){
  clientes_ativos = servidor_ativo = 0;
  servidor_p_buf_ativo =  servidor_p_fila_ativo = 0;
  time_t start;
  time(&start);

  Servidor* servidor = cria_servidor(cria_disco(),buffer_inicializa(tam_buf));
  fprintf(fileptr,"Disco n bloco = %d, tam blco = %d, rpm = %d\n", servidor->disco->n_bloco,servidor->disco->tam_bloco,servidor->disco->rpm);
  Servidor_proxy* servidor_p = cria_servidor_proxy(fila_cria(),buffer_inicializa(tam_buf),usa_elevador,entrel);
  Cliente* clientes[NUM_CLIENTES];
  for(uint i = 0;i<clientes_ale;i++) clientes[i] = cria_cliente(buffer_inicializa(tam_buf),i,0);
  for(uint i = clientes_ale;i<NUM_CLIENTES;i++) clientes[i] = cria_cliente(buffer_inicializa(tam_buf),i,1);
  run_servidor_disco(servidor,1,servidor_p->usa_elevador);
  run_servidor_proxy(servidor_p,servidor);
  for(uint i = 0;i<NUM_CLIENTES;i++) run_cliente(clientes[i],servidor,servidor_p);

  servidor_proxy_cliente_join(fileptr,clientes,servidor,servidor_p,start);

  for(uint i = 0;i<NUM_CLIENTES;i++) finaliza_cliente(clientes[i]);
  finaliza_servidor_proxy(servidor_p);
  finaliza_servidor(servidor);
}

static void servidor_proxy_cliente_test_(FILE* fileptr, uint tam_buf, bool usa_elevador){
  uint sequencial[COMB_SEQ_ALE] = {0,1,2,3,4,5,6};
  uint aleatorio[COMB_SEQ_ALE] = {6,5,4,3,2,1,0};
  for(uint  j = 0;j<3;j++){
    for(uint i = 0;i<COMB_SEQ_ALE;i++){
      fprintf(fileptr, "Tam Buf servidor = %d, Num clientes aleatorios = %d, num clientes sequencial = %d ",tam_buf,aleatorio[i],sequencial[i]);
      fprintf(fileptr, "usa elevador = %d, entrel = %d\n", usa_elevador,j+1);
      servidor_proxy_cliente(fileptr,tam_buf,sequencial[i],aleatorio[i],usa_elevador,j+1);
    }
  }

}


void servidor_proxy_cliente_test(){
  uint n = 2;
  FILE* files[n];
  char path[100];
  bool elevador  = true;
  printf("Teste servidor proxy cliente\n");
  for(uint i = 0;i<n;i++){
    snprintf(path, 100, "Data/servidor_proxy_cliente/st%d.txt", i);
    files[i] = fopen(path, "w");
    if(files[i]==NULL){printf("Erro ao criar arquivo %d\n",i);return ;}
    servidor_proxy_cliente_test_(files[i], 10000,elevador);
    fclose(files[i]);
    elevador=!elevador;
  }

}

static void servidor_cliente_test_(FILE* fileptr, uint tam_buf){
  uint sequencial[COMB_SEQ_ALE] = {0,1,2,3,4,5,6};
  uint aleatorio[COMB_SEQ_ALE] = {6,5,4,3,2,1,0};
  for(uint i = 0;i<COMB_SEQ_ALE;i++){
    fprintf(fileptr, "Tam Buf servidor = %d, Num clientes aleatorios = %d, num clientes sequencial = %d\n",tam_buf,aleatorio[i],sequencial[i]);
    servidor_cliente(fileptr,tam_buf,sequencial[i],aleatorio[i]);
  }

}

void servidor_cliente_test(){
  uint n = 2;
  FILE* files[n];
  char path[100];
  uint tam_buf = 10000;
  printf("Teste servidor cliente\n");
  for(uint i = 0;i<n;i++){
    snprintf(path, 100, "Data/servidor_cliente/test%d.txt", i);
    files[i] = fopen(path, "w");
    if(files[i]==NULL){printf("Erro ao criar arquivo %d\n",i);return ;}
    servidor_cliente_test_(files[i], tam_buf);
    fclose(files[i]);
    tam_buf*=10;
  }

}
