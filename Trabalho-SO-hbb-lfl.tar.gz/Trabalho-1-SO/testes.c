#include"testes.h"

#include<sched.h>

#define MAX_IT 1000
#define COMB_L_E 5
#define QNT_TAMS 5
#define TIPOS_INSERCOES 6

int escritores_ativos = 0;


//--------------------------------------- Funções Gerais  --------------------------------------

//Retorna um vetor de tamanho randomico entre lower e upper
//com todas as posições preenchidas com o primeiro byte de tam.
static void* return_data_(uint lower, uint upper, uint* tam){
    uint bytes_size = (rand()%(upper - lower + 1)) + lower;
    *tam = bytes_size;
    void* data =  malloc(sizeof(*data)*bytes_size);
    for(uint i = 0 ; i<bytes_size;i++){
        memcpy(data+i,tam,1);
    }
    return data;
}

//Escolhe qual o lower e upper da função return_data_.
static void* return_data(uint size_option, uint* tam, uint buf_tam){
  void* p = NULL;
  switch(size_option){
    case 0: p = return_data_(4,buf_tam-5, tam);
      break;
    case 1: p = return_data_(4,(2*buf_tam)/3, tam);
      break;
    case 2: p = return_data_(4,buf_tam/2, tam);
      break;
    case 3: p = return_data_(4,buf_tam/4, tam);
      break;
    case 4: p = return_data_(buf_tam/4,buf_tam-5, tam);
      break;
    case 5: p = return_data_((2*buf_tam)/3,buf_tam-5, tam);
      break;
  }
  return p;
}


//--------------------------------------- Funções de uma ou nenhuma thread  para trabalhar com um Buffer   --------------------------------------

//Remove de um buffer, de tres maneiras diferentes, que dependem de thread e bloqueante.
//Retorna a quantidade removida ou 0.
static uint remove_bytes(Buffer* buf, bool* resp, bool thread, bool bloqueante){
    char data[buf->tam];
    uint tam = 0;
    for(uint i = 0 ; i<buf->tam;i++){
        data[i] = '\0';
    }
    uint cap = rand()%(buf->tam+1);

    if(thread){
      if(bloqueante)
        *resp = buffer_remove_nao_bloqueante_simples(buf,data,cap,&tam);
      else
        *resp = buffer_remove_bloqueante_simples(buf,data,cap,&tam);
    }else{
      *resp = buffer_remove(buf,data,cap,&tam);
    }

    if(*resp){
        if(cap>tam)
            return (4+tam);
        else
            return (4+cap);
    }
    return 0;
}

//Insere em um buffer, de tres maneiras diferentes, que dependem de thread e bloqueante.
//Retorna a quantidade removida ou 0.
static uint insert_bytes(Buffer* buf, bool* resp, void* p, uint tam, bool thread, bool bloqueante){
    if(thread){
      if(bloqueante)
        *resp = buffer_insere_nao_bloqueante_simples(buf,p,tam);
      else
        *resp = buffer_insere_bloqueante_simples(buf,p,tam);
    }else{
      *resp = buffer_insere(buf,p,tam);
    }
    free(p);
    if(*resp){
      return (4+tam);
    }
    return 0;
}


//--------------------------------------- Funções de uma ou nenhuma thread para trabalhar com um Buffer   --------------------------------------

//Função que insere ou remove dependendo de uma variavel randômica.
//O tempo de execução é calculado aqui.
static void test_buffer_rand(FILE* fileptr, Buffer* buf, uint size_option, bool thread, bool bloqueante){
    time_t start, end;
    uint counter = 0, validas = 0, result = 0,insere,tam;
    bool resp = 0;
    void* p = NULL;
    time(&start);
    do{
        insere = rand()%2;
        if(insere){
            p = return_data(size_option,&tam,buf->tam);
            result+=insert_bytes(buf, &resp, p, tam, thread, bloqueante);
        }else{
            result+=remove_bytes(buf, &resp, thread, bloqueante);
        }

        if(resp) validas++;
        counter++;
        time(&end);
    }while(difftime(end, start)<1);
    fprintf(fileptr," Insertion size type = %d", size_option);
    fprintf(fileptr," Inseridos/Removidos = %d bytes/seg, inserções válidas = %d, inserções = %d\n", result, validas,counter);
}

//Função que testa a sequencia insere-remove-insere-...
//O tempo de execução é calculado aqui.
static void test_buffer_nonrand(FILE* fileptr, Buffer* buf, uint size_option, bool thread, bool bloqueante){
    time_t start, end;
    uint counter = 0, validas = 0, result = 0, tam;
    bool resp = 0, insere = 1;
    time(&start);
    do{
      if(insere){
          void* p = return_data(size_option,&tam,buf->tam);
          result+=insert_bytes(buf, &resp, p, tam, thread, bloqueante);
      }else{
          result+=remove_bytes(buf, &resp, thread, bloqueante);
      }
      insere=1-insere;
      if(resp) validas++;
      counter++;
      time(&end);
    }while(difftime(end, start)<1);
    fprintf(fileptr," Insertion size type = %d", size_option);
    fprintf(fileptr," Inseridos/Removidos = %d bytes/seg, inserções válidas = %d, inserções = %d\n", result, validas,counter);
}

//Testa diferentes tam de buffer e variação de tam min e max dos dados a serem inseridos.
static void test_buffer(FILE* fileptr,bool thread, bool bloqueante, bool rand){
  uint cap = 100;
  for(uint j = 0;j<QNT_TAMS;j++){
    fprintf(fileptr, "Tam = %d, bloqueante = %d, rand = %d\n",cap, bloqueante, rand);
    for(uint i = 0;i<TIPOS_INSERCOES;i++){
      Buffer* buffer = buffer_inicializa(cap);
      if(buffer==NULL)
        continue;
      if(rand)
        test_buffer_rand(fileptr,buffer,i,thread,bloqueante);
      else
        test_buffer_nonrand(fileptr,buffer,i,thread,bloqueante);

      buffer_finaliza(buffer);
    }
    cap*=10;
  }
}


//--------------------------------------- Funções de Teste para  uma thread  --------------------------------------

//Testa a combinação entre o tipo de mudança de operação no buffer entre
// rand ou não e também  se a inserção vai ser bloqueante.
// Cria um arquvio txt para salvar os resultados.
static void* one_thread_test_(void* args){
  uint n = 4;
  FILE* files[n];
  bool rand = true, bloqueante = true;
  char path[100];

  printf("Teste com uma thread\n");
  for(uint i = 0;i<n;i++){
    if(i%2==0) bloqueante = !bloqueante;
    if(i%2==1) rand = !rand;
    snprintf(path, 100, "Data/one_thread/test%d.txt", i);
    files[i] = fopen(path, "w");
    if(files[i]==NULL){printf("Erro ao criar arquivo %d\n",i);return NULL;}
    test_buffer(files[i],true,bloqueante,rand);
    fclose(files[i]);
  }
  return NULL;
}

//Cria e chama uma thread passando a função one_thread_test_.
void one_thread_test(){
  pthread_t thread;
  void* val;
  int status = pthread_create(&thread,NULL,one_thread_test_,NULL);
  if(status == -1) printf("Erro\n");
  pthread_join(thread,&val);
}


//--------------------------------------- Funções de Teste para nenhuma thread  --------------------------------------

//Testa a combinação entre o tipo de mudança de operação no buffer entre
// rand ou não. Cria um arquvio txt para salvar os resultados.
void no_thread_test(){
  uint n = 2;
  FILE* files[2];
  bool rand  = false;
  char path[100];

  printf("Teste sem thread\n");
  for(uint i = 0;i<n;i++){
    snprintf(path, 100, "Data/no_thread/test%d.txt", i);
    files[i] = fopen(path, "w");
    if(files[i]==NULL){printf("Erro ao criar arquivo %d\n",i);return ;}
    test_buffer(files[i],false,false,rand);
    rand=!rand;
    fclose(files[i]);
  }
}



//--------------------------------------- Estrutura para passar argumentos pelo pthread_create  --------------------------------------

typedef struct{
  Buffer* buf;
  bool bloqueante;
  uint size_option;
}Thread_arg;

//Inicializa a estrutura que vai ser o ultimo parametro
// em pthread_create para o teste multithread.
static Thread_arg* init_thread_arg(Buffer* buf,bool bloqueante, uint size_option){
  Thread_arg* thread_arg = malloc(sizeof(*thread_arg));
  thread_arg->buf = buf;
  thread_arg->bloqueante = bloqueante;
  thread_arg->size_option = size_option;
  return thread_arg;
}

//Finaliza a estrutura que é parametro para as chamadas das threads.
static void finaliza_thread_arg(Thread_arg* thread_arg){
  buffer_finaliza(thread_arg->buf);
  free(thread_arg);
}


//--------------------------------------- Funções de multithread para trabalhar com um BUFFER  --------------------------------------

//Fica inserindo sem bloquear ou bloqueando MAX_IT vezes.
void* multithread_insere(void* args){
  ++escritores_ativos;
  Thread_arg* thread = (Thread_arg*)args;
  uint i =0, tam = 0,falhas = 0, result_ =  0;
  bool ans = false;
  while(i<MAX_IT){
    void* p = return_data(thread->size_option,&tam,thread->buf->tam);
    if(thread->bloqueante) ans = buffer_insere_bloqueante(thread->buf,p,tam);
    else ans = buffer_insere_nao_bloqueante(thread->buf,p,tam);
    if(!ans)falhas++;
    else result_+=tam;
    i++;
    free(p);
    usleep(1);
  }
  --escritores_ativos;
  return NULL;
}

//Fica removendo sem bloquear ou bloqueando ate que não exista mais
// escritores ativos e o buffer esteja vazio.
void* multithread_remove(void* args){
  Thread_arg* thread = (Thread_arg*)args;
  uint i =0, tam = 0, falhas = 0, result_ = 0;
  bool ans =false;
  while(escritores_ativos==0) sched_yield();
  while(escritores_ativos!=0 || buffer_ndados(thread->buf)>0){
    char p[thread->buf->tam];
    if(thread->bloqueante) ans = buffer_remove_bloqueante(thread->buf,p,thread->buf->tam,&tam);
    else ans = buffer_remove_nao_bloqueante(thread->buf,p,thread->buf->tam,&tam);
    if(!ans) falhas++;
    else result_+=tam;
    i++;
    usleep(1);
  }
  return NULL;
}


//--------------------------------------- Funções de Teste para multithread  --------------------------------------

//Teste multihread generico que recebe a quantidade de escritores, leitores
//O tempo do teste multithread é calculado aqui. Ele começa a contar quando
// as threads são criadas e para quando todas dão join.

static void multithread(FILE* fileptr,uint num_escritores, uint num_leitores,bool bloqueante, uint size_option, uint buf_size){
  pthread_t* escritores = malloc(sizeof(*escritores)*num_escritores);
  pthread_t* leitores = malloc(sizeof(*leitores)*num_leitores);
  time_t start, end;
  Thread_arg* thread_arg = init_thread_arg(buffer_inicializa(buf_size),bloqueante,size_option);
  int status = 0;
  void* val;
  time(&start);
  for(uint  i = 0;i<num_escritores;i++) status = pthread_create(&escritores[i],NULL,multithread_insere,thread_arg);
  for(uint  i = 0;i<num_leitores;i++) status = pthread_create(&leitores[i],NULL,multithread_remove,thread_arg);
  for(uint  i = 0;i<num_escritores;i++) pthread_join(escritores[i],&val);
  for(uint  i = 0;i<num_leitores;i++) pthread_join(leitores[i],&val);
  time(&end);
  uint resp = (thread_arg->buf->qnt_inserida+thread_arg->buf->qnt_removida)/difftime(end, start);
  fprintf(fileptr," Insertion size type = %d, Inseridos/Removidos = %d bytes/seg\n",size_option,resp);

  free(leitores);
  free(escritores);
  finaliza_thread_arg(thread_arg);
}

//Testa várias combinações de leitores e escritores e chama a função
// multithread. Também testa os tamanhos lower e upper do return_data_.
static void multithread_test_(FILE* fileptr, bool bloqueante){
  uint num_escritores[COMB_L_E] = {2,5,5,10,10};
  uint num_leitores[COMB_L_E] = {2,5,10,5,2};
  uint buf_size = 100000;
  for(uint i = 0;i<COMB_L_E;i++){
    fprintf(fileptr, "Tam = %d, num escritores = %d, num leitores = %d, bloqueante = %d\n",buf_size,num_escritores[i],num_leitores[i],bloqueante);
    for(uint j = 0;j<TIPOS_INSERCOES;j++){
        multithread(fileptr,num_escritores[i],num_leitores[i],bloqueante,j,buf_size);
    }
  }

}

//FUnção de teste multihtread que testa operações no buffer bloqueantes ou não.
void multithread_test(){
  uint n = 2;
  FILE* files[n];
  char path[100];
  bool bloqueante = false;

  printf("Teste multithread_\n");
  for(uint i = 0;i<2;i++){
    snprintf(path, 100, "Data/multithread/test%d.txt", i);
    files[i] = fopen(path, "w");
    if(files[i]==NULL){printf("Erro ao criar arquivo %d\n",i);return ;}
    multithread_test_(files[i],bloqueante);
    bloqueante=!bloqueante;
    fclose(files[i]);
  }

}
