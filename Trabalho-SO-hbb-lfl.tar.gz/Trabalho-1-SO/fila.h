struct no {
   void* dados;
   struct no* prox;
   struct no* ant;
};

typedef struct no No;

struct fila {
   No* ini;
   No* fim;
};

typedef struct fila Fila;


Fila* fila_cria (void);

bool fila_insere (Fila* f, void* v);
void* fila_retira (Fila* f);
void* fila_retira_no(Fila *f, No *no);

int fila_vazia (Fila* f);
void fila_libera (Fila* f);

void* fila_top(Fila* f);

int fila_tamanho(Fila* f);
