#ifndef Testes_H_INCLUDED
#define Testes_H_INCLUDED

#include<time.h>
#include"buffer.h"

void no_thread_test();

void one_thread_test();

void multithread_test();
#endif
