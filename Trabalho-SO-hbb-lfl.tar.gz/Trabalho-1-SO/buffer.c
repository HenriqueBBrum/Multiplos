#include"buffer.h"

//--------------------------------------- Funções gerais do Buffer --------------------------------------


//Inicializa um buffer e suas variaveis.
Buffer* buffer_inicializa(uint cap){
    Buffer* buffer_aux =  malloc(sizeof(Buffer));
    if(buffer_aux == NULL)
      return NULL;

    buffer_aux->tam = cap;
    buffer_aux->fim = buffer_aux->inicio = -1;
    buffer_aux->qnt_removida = 0;
    buffer_aux->qnt_inserida = 0;
    buffer_aux->qnt_elementos = 0;
    buffer_aux->dados = (void*)malloc(cap);
    for(uint i = 0;i<cap;i++){
        memcpy(buffer_aux->dados+i,&buffer_aux->qnt_elementos,1);
    }
    if(buffer_aux->dados == NULL)
      return NULL;

    buffer_aux->insercoes = fila_cria();
    buffer_aux->remocoes = fila_cria();

    buffer_aux->mutex = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
    buffer_aux->mutex_f_insercoes = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
    buffer_aux->mutex_f_remocoes = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
    buffer_aux->inserir = (pthread_cond_t)PTHREAD_COND_INITIALIZER;
    buffer_aux->remover = (pthread_cond_t)PTHREAD_COND_INITIALIZER;

    return buffer_aux;
}

//Retorna q quantidade de elementos no buffer
uint buffer_ndados(Buffer* buf){return buf->qnt_elementos;}

//Retorna a quantidade de bytes livre
uint buffer_livre(Buffer* buf){
    uint livre = 0;

    if(buf->fim<buf->inicio){
        livre = buf->inicio-buf->fim;
    }else if(buf->fim>buf->inicio){
        livre = buf->tam -(buf->fim-buf->inicio);
    }else if(buf->fim == -1){
        livre = buf->tam;
    }else if(buf->fim == buf->inicio && buf->fim!=-1){
        livre = 0;
    }

    return livre;
}

//Libera a memória alocado pelo buffer, o vetor de dados e as filas.
//Destroi as variaveis condicionais e os mutexes
void buffer_finaliza(Buffer* buf){
    free(buf->dados);
    fila_libera(buf->insercoes);
    fila_libera(buf->remocoes);
    pthread_mutex_destroy(&buf->mutex);
    pthread_mutex_destroy(&buf->mutex_f_insercoes);
    pthread_mutex_destroy(&buf->mutex_f_remocoes);
    pthread_cond_destroy(&buf->inserir);
    pthread_cond_destroy(&buf->remover);
    free(buf);
}

//--------------------------------------- Funções de Inserção --------------------------------------


//Header que indica o tam, fica parte no fim e no inicio.
static void insere_separado_1(Buffer* buf,void*p, uint ate_volta, uint tam){
    unsigned char tempArray[] = {0x00, 0x00, 0x00, 0x00};
    uint tam_aux = tam;
    for(int i = 0; i<4;i++){
      tempArray[i] = tam_aux&0xFF;
      tam_aux = tam_aux>>8;
    }
    memcpy(buf->dados+buf->fim,tempArray,ate_volta);
    buf->fim = 0;
    memcpy(buf->dados+buf->fim,tempArray+ate_volta,sizeof(tam)-ate_volta);

    buf->fim+=(sizeof(tam)-ate_volta);
    memcpy(buf->dados+buf->fim, p, tam);
    buf->fim+=tam;
}

//Dados ficam  no fim e no inicio do buffer.
static void insere_separado_2(Buffer* buf,void* p, uint ate_volta, uint tam){
    memcpy(buf->dados+buf->fim,&tam,sizeof(tam));
    buf->fim+=sizeof(tam);
    ate_volta = buf->tam - buf->fim;
    memcpy(buf->dados+buf->fim,p,ate_volta);
    buf->fim = 0;
    memcpy(buf->dados+buf->fim,p+ate_volta,tam - ate_volta);
    buf->fim=(tam-ate_volta);
}

//Caso o header ou os dados fiquem parte no fim e parte no inicio.
static void insere_separado(Buffer* buf, void* p, uint tam){
    uint tam_header = sizeof(tam);
    uint ate_volta = buf->tam - buf->fim;

    if(ate_volta<=tam_header){
        insere_separado_1(buf,p,ate_volta,tam);
    }else{
        insere_separado_2(buf,p,ate_volta,tam);
    }
    buf->qnt_elementos++;
}

//Insere um dado no buf com tam bytes.
bool buffer_insere(Buffer* buf, void* p, uint tam){
    if(tam<0)
        return false;

    uint tam_total = tam+4;
    uint livre = buffer_livre(buf);

    if(livre<tam_total)  return false;


    if(buf->inicio == -1)
        buf->inicio = buf->fim = 0;

    if((tam_total+buf->fim) >= buf->tam){
        insere_separado(buf,p,tam);
        return true;
    }

    buf->qnt_elementos++;
    memcpy(buf->dados+buf->fim,&tam,4);
    buf->fim+=4;
    memcpy(buf->dados+buf->fim,p,tam);
    buf->fim+=tam;
    return true;
}

//Tenta pegar o mutex, caso consiga fica esperando ter espaço para inserir.
//Caso não, retorna pra função que a chamou.
bool buffer_insere_nao_bloqueante(Buffer* buf, void* p, uint tam){
    bool ans = false;
    if (pthread_mutex_trylock(&buf->mutex) == 0){
        while(buffer_livre(buf)<=0) pthread_cond_wait(&buf->inserir, &buf->mutex);
        ans = buffer_insere(buf,p,tam);

        if(ans){
          buf->qnt_inserida+=(4+tam);
          pthread_cond_signal(&buf->remover);
        }
        pthread_mutex_unlock(&buf->mutex);

    }
    return ans;
}

//Igual a função nao bloqueante só que não fica esperando o buffer_remove
// ter espaço. Usado no teste de uma thread
bool buffer_insere_nao_bloqueante_simples(Buffer* buf, void* p, uint tam){
    bool ans = false;
    if (pthread_mutex_trylock(&buf->mutex) == 0){
        ans = buffer_insere(buf,p,tam);
        pthread_mutex_unlock(&buf->mutex);

    }

    return ans;
}

//Insere em uma fila de threads que querem inserir, quando for sua vez
// da lock no mutex e espera ter espaço para inserir, depois libera o mutex
// e sai da fila.
bool buffer_insere_bloqueante(Buffer* buf, void* p, uint tam){
    bool ans = false;
    long int self = pthread_self();

    pthread_mutex_lock(&buf->mutex_f_insercoes);
    fila_insere(buf->insercoes,&self);
    pthread_mutex_unlock(&buf->mutex_f_insercoes);

    while(pthread_self()!=*((long int*)fila_top(buf->insercoes))) usleep(1);

    pthread_mutex_lock(&buf->mutex);
    while (buffer_livre(buf)<=0) pthread_cond_wait(&buf->inserir, &buf->mutex);
    ans = buffer_insere(buf,p,tam);
    if(ans) buf->qnt_inserida+=tam;

    pthread_cond_signal(&buf->remover);
    pthread_mutex_unlock(&buf->mutex);

    pthread_mutex_lock(&buf->mutex_f_insercoes);
    fila_retira(buf->insercoes);
    pthread_mutex_unlock(&buf->mutex_f_insercoes);

    return ans;
}

//Só tenta conseguir o mutex do buffer e fica esperando até ser sua vez.
//Usado no teste de uma thread
bool buffer_insere_bloqueante_simples(Buffer* buf, void* p, uint tam){
    bool ans = false;
    pthread_mutex_lock(&buf->mutex);
    ans = buffer_insere(buf,p,tam);

    pthread_cond_signal(&buf->remover);
    pthread_mutex_unlock(&buf->mutex);

    return ans;
}



//--------------------------------------- Funções de Remoção --------------------------------------

//Retira dados que tenham ficado com parte no fim e no inicio.
//Tambem cuida do caso em que a parte dos dados restriginda por cap não é
// separado mas os dados por inteiro estão.
static void remove_separado(Buffer* buf, void* p , uint retirar, uint tam_total){
    uint ate_volta = buf->tam - buf->inicio;
    if(retirar<=ate_volta){
        memcpy(p,buf->dados+buf->inicio,retirar);
        buf->inicio+=retirar;
        ate_volta = buf->tam - buf->inicio;
        buf->inicio+=ate_volta;
        buf->inicio=tam_total-ate_volta-retirar;
    }else{
        memcpy(p,buf->dados+buf->inicio,ate_volta);
        buf->inicio=0;
        memcpy(p,buf->dados+buf->inicio,retirar-ate_volta);
        buf->inicio=(retirar-ate_volta)+(tam_total-retirar);
    }
    if(buf->fim==buf->inicio)
        buf->fim=buf->inicio=-1;
}

//Le o header de cada dado inserido esteja esse header alocado contiguamente
// ou separado.
static void pega_tam(Buffer* buf, uint* tam){

    const uint ate_volta = buf->tam - buf->inicio;
    if(ate_volta<=4){
        unsigned char tempArray[] = {0x00, 0x00, 0x00, 0x00};
        memcpy(tempArray,buf->dados+buf->inicio,ate_volta);
        buf->inicio=0;
        memcpy(tempArray+ate_volta,buf->dados,4-ate_volta);
        buf->inicio=4-ate_volta;
        *tam = tempArray[0] | ((uint)tempArray[1]<<8) | ((uint)tempArray[2]<<16) | ((uint)tempArray[3]<<24);
    }else{
        memcpy(tam,buf->dados+buf->inicio,4);
        buf->inicio+=4;
    }
}

//Função que remove cap bytes de um dado do buffer.
bool buffer_remove(Buffer* buf, void* p, uint cap, uint* tam){
    if(buf->qnt_elementos == 0  || cap == 0) return false;

    pega_tam(buf, tam);
    uint retirar = 0, tam_total = 0;

    if(cap>*tam){
          tam_total = retirar =  *tam;
    }else{
        retirar =  cap;
        tam_total = *tam;
    }

    buf->qnt_elementos--;
    if((tam_total+buf->inicio) >= buf->tam){
        remove_separado(buf,p,retirar,tam_total);
        return true;
    }
    memcpy(p,buf->dados+buf->inicio,retirar);
    buf->inicio+=tam_total;
    if(buf->fim==buf->inicio)
        buf->fim=buf->inicio=-1;

    return true;
}

//Função utilizado para dar um tempo minimo de espera para o cond_wait.
static struct timespec* tempo_esp(int tempo_ms){
  struct timespec* tempo_esp =  malloc(sizeof(*tempo_esp));
  struct timeval agora;
  gettimeofday(&agora,NULL);
  tempo_esp->tv_sec = agora.tv_sec+5;
  tempo_esp->tv_nsec = (agora.tv_usec+1000UL*tempo_ms)*1000UL;
  return tempo_esp;
}

//Tenta dar lock no mutex do buffer, caso consiga; fica esperando por um sinal da thread de inserção
// caso esse sigsinalnal demore mais que tmp_esp micro seg a thread segue;
// caso não consiga só retorna.
//A decisão por usar um tempo limite, é pq as remoções são dependentes das inserções.
//Logo caso não tenha mais ninguem inserindo, não vai ter ninguem mandando sinal
// de remoção e a thread de remoção fica bloqueada
bool buffer_remove_nao_bloqueante(Buffer* buf, void*p, uint cap, uint* tam){
    bool ans = false;
    if (pthread_mutex_trylock(&buf->mutex) == 0){
        struct timespec* tmp_esp = tempo_esp(1);
        if(buffer_ndados(buf)<=0) pthread_cond_timedwait(&buf->remover, &buf->mutex, tmp_esp);
        ans = buffer_remove(buf,p,cap,tam);
        if(ans){
          buf->qnt_removida+=(4+*tam);
          pthread_cond_signal(&buf->inserir);
        }
        free(tmp_esp);
        pthread_mutex_unlock(&buf->mutex);
    }
    return ans;
}

//Só tenta dar lock no mutex do buffer. Usado no teste de uma thread
bool buffer_remove_nao_bloqueante_simples(Buffer* buf, void*p, uint cap, uint* tam){
    bool ans = false;
    if (pthread_mutex_trylock(&buf->mutex) == 0){
        ans = buffer_remove(buf,p,cap,tam);

        pthread_mutex_unlock(&buf->mutex);
    }
    return ans;
}

//Faz o mesmo processo que a buffer_insere_bloqueante em relação a fila_top.
//E faz igual a buffer_remove_nao_bloqueante na questão da espera por um sinal
bool buffer_remove_bloqueante(Buffer* buf, void*p, uint cap, uint* tam){
  bool ans = false;
  struct timespec* tmp_esp = tempo_esp(1);
  long int self = pthread_self();

  pthread_mutex_lock(&buf->mutex_f_remocoes);
  fila_insere(buf->remocoes,&self);
  pthread_mutex_unlock(&buf->mutex_f_remocoes);

  while(pthread_self()!=*((long int*)fila_top(buf->remocoes)))usleep(1);

  pthread_mutex_lock(&buf->mutex);
  if(buffer_ndados(buf)<=0) pthread_cond_timedwait(&buf->remover, &buf->mutex, tmp_esp);

  ans = buffer_remove(buf,p,cap,tam);
  if(ans) buf->qnt_removida+=*tam;

  pthread_cond_signal(&buf->inserir);
  pthread_mutex_unlock(&buf->mutex);

  pthread_mutex_lock(&buf->mutex_f_remocoes);
  fila_retira(buf->remocoes);
  pthread_mutex_unlock(&buf->mutex_f_remocoes);

  free(tmp_esp);
  return ans;
}

//Igual a buffer_insere_bloqueante_simples só que para a remoção
//Usado no teste de uma thread
bool buffer_remove_bloqueante_simples(Buffer* buf, void*p, uint cap, uint* tam){
  bool ans = false;

  pthread_mutex_lock(&buf->mutex);
  ans = buffer_remove(buf,p,cap,tam);
  pthread_mutex_unlock(&buf->mutex);

  return ans;
}
