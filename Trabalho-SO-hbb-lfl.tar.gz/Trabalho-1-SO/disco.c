#include"disco.h"


// aloca e inicializa uma estrutura que descreve um disco
disco_t *disco_init(int32_t tam_bloco, int32_t n_cil, int32_t n_sup,
                    int32_t n_set, int32_t rpm, int32_t t_busca, int32_t t_cil)
{
  int32_t n_bloco = n_cil * n_sup * n_set;
  disco_t *disco = malloc(n_bloco*tam_bloco);
  if (disco == NULL) return disco;
  disco->magico = MAGICO;
  disco->n_bloco = n_bloco;
  disco->tam_bloco = tam_bloco;
  disco->n_cil = n_cil;
  disco->n_sup = n_sup;
  disco->n_set = n_set;
  disco->rpm = rpm;
  disco->t_busca = t_busca;
  disco->t_cil = t_cil;
  disco->cil_atual = -1;
  return disco;
}

// inicializa um disco a partir de uma imagem em arquivo
disco_t *disco_init_arquivo(char *nome_arq)
{
  FILE *arq;
  arq = fopen(nome_arq, "r");
  if (arq == NULL) return NULL;
  disco_t d;
  if (fread(&d, sizeof(d), 1, arq) != 1) {
    fclose(arq);
    return NULL;
  }
  if (d.magico != MAGICO) {
    fclose(arq);
    return NULL;
  }
  disco_t *disco = malloc(d.n_bloco*d.tam_bloco);
  if (disco == NULL) {
    fclose(arq);
    return NULL;
  }
  rewind(arq);
  if (fread(disco, d.tam_bloco, d.n_bloco, arq) != d.n_bloco) {
    free(disco);
    fclose(arq);
    return NULL;
  }
  fclose(arq);
  return disco;
}

// grava a imagem de um disco em arquivo
void disco_grava_arquivo(disco_t *disco, char *nome_arq)
{
  if (disco->magico != MAGICO) return;
  FILE *arq;
  arq = fopen(nome_arq, "w");
  if (arq == NULL) return;
  fwrite(disco, disco->tam_bloco, disco->n_bloco, arq);
  fclose(arq);
}

// acaba com o disco
void disco_fim(disco_t *disco)
{
  free(disco);
}

// que horas sao
static double agora(void)
{
  struct timespec tf;
  clock_gettime(CLOCK_MONOTONIC_RAW, &tf);
  return tf.tv_sec+tf.tv_nsec/1e9;
}

// a que horas vai estar terminada a operacao com o disco que comeca agora
static double ate_quando_esperar(disco_t *disco, int bloco)
{
  //zzprintf("BLoco = %d, n_bloco %d, tam_bloco = %d, rpdm = %d, tempo_busca = %d\n", bloco,disco->n_bloco,disco->tam_bloco,disco->rpm,disco->t_busca);
  double inicio = agora();
  double t_busca = 0;
  int cil = bloco / (disco->n_sup * disco->n_set);
  if (cil != disco->cil_atual) {
    int t_busca_us;
    t_busca_us = disco->t_busca;
    t_busca_us += (abs(cil - disco->cil_atual) * disco->t_cil);
    t_busca = t_busca_us / 1e6;
    disco->cil_atual = cil;
  }
  double depois_da_busca = inicio + t_busca;
  // quando terminar a busca, quanto tempo até o setor chegar no cabecote?
  // considera que o disco estava no inicio do setor 0 no tempo 0
  double rps = disco->rpm / 60.0;
  double t_1rot = 1/rps; // segundos por rotacao
  long rotacoes = depois_da_busca / t_1rot; // rotacoes completas desde t=0
  double t_rot = depois_da_busca - rotacoes * t_1rot; // t na rot atual
  double t_1set = t_1rot / disco->n_set; // tempo para 1 setor
  int set = bloco % disco->n_set; // setor que quero, na trilha
  double t_set = set*t_1set; // tempo do inicio da trilha ate inicio do setor
  double espera_rot = t_set - t_rot;
  if (espera_rot < 0) espera_rot += t_1rot; // espera mais uma rotacao
  double depois_da_espera_rot = depois_da_busca + espera_rot;
  // depois de esperar o setor chegar, tem que esperar ele ser transferido
  // supoe que o tempo de transferencia é simplesmente o tempo de passar o setor
  return depois_da_espera_rot + t_1set;
}

// onde está o bloco?
static void *end_bloco(disco_t *disco, int bloco)
{
  return (void *)((char *)disco + bloco * disco->tam_bloco);
}

// le um bloco do disco, coloca em buf
void disco_le(disco_t *disco, int bloco, void *buf)
{
  if(bloco >=disco->n_bloco)
    return;
  double fim = ate_quando_esperar(disco, bloco);
  memcpy(buf, end_bloco(disco, bloco), disco->tam_bloco);

  double espera = (fim-agora())*1e6;

  if(espera>0)
    usleep(espera);

}

// grava um bloco no disco, a partir do conteúdo em buf
void disco_grava(disco_t *disco, int bloco, void *buf)
{
  if(buf==NULL) return;
  if(bloco >=disco->n_bloco)
    return;
  double fim = ate_quando_esperar(disco, bloco);
  memcpy(end_bloco(disco, bloco), buf, disco->tam_bloco);
  double espera = (fim-agora())*1e6;

  if(espera>0)
    usleep(espera);
}
